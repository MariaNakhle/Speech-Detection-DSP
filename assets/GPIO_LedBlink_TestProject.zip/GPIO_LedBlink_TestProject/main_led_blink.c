
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/cfg/global.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Swi.h>

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

/* TI-RTOS Header files */
#include <ti/drv/gpio/GPIO.h>
#include <ti/drv/gpio/soc/GPIO_soc.h>

//#include "GPIO_log.h"
#include "GPIO_board.h"

#include "DATA.h"


#include <ti/board/board.h>
#include <ti/csl/csl_clec.h>

#define N 1162       //size array

float squareWave[N];
int fs=1000;
int idx=0;
float sample=0;

float envelope[N];
float DATAclear [N];
float DATAabs[N];
float alpha = 0.1;
float threshold = 0.1;
float envelopeSample=0.0;
int ledFlag=0;
/**********************************************************************
 ************************** Internal functions ************************
 **********************************************************************/
/*
 *  ======== Board_initI2C ========
 */

static void Board_initGPIO(void)
{
    Board_initCfg boardCfg;
    GPIO_v0_HwAttrs gpio_cfg;
    /* Get the default SPI init configurations */
    GPIO_socGetInitCfg(GPIO_LED0_PORT_NUM, &gpio_cfg);
    /* Setup GPIO interrupt configurations */
    boardCfg = BOARD_INIT_PINMUX_CONFIG |
        BOARD_INIT_MODULE_CLOCK |
        BOARD_INIT_UART_STDIO;
    Board_init(boardCfg);
}

/**********************************************************************
 ************************** Global Variables **************************
 **********************************************************************/
volatile uint32_t gpio_intr_triggered = 0;
uint32_t gpioBaseAddr;
uint32_t gpioPin;

/*
 *  ======== test function ========
 */

void gpio_test(UArg arg0, UArg arg1)
{
 //   Board_initGPIO();

//    uint32_t testOutput = 1;

    /* GPIO initialization */
    GPIO_init();
    /* Write high to gpio pin to control LED1 */
    GPIO_write((USER_LED1), GPIO_PIN_VAL_HIGH);

    while(1)
    {
        GPIO_toggle(USER_LED0);
    }

}

void timerIsr(void)
{


       Swi_post(swi0);


}


void SW_Interrupt(void) {

    if (idx >= N - 1) {
        idx = 0;
    } else {
        idx++;
    }
    sample = DATA[idx];
    Semaphore_post(semaphore0); // Post semaphore

}



float IIR_4thOrder_Cascaded() {
    // Coefficients for the first 2nd-order section (Section 1)
    float b0_1 = 1.0;                  // Numerator coefficients for Section 1
    float b1_1 = 1.9999132166774349;   // From Section #1 Numerator
    float b2_1 = 1.0;

    float a1_1 = -1.2082462285592639;   // Denominator coefficients for Section 1
    float a2_1 = 0.5781139737408525;

    // Gain for Section 1
    float gain_1 = 0.5874679077681033;

    // Coefficients for the second 2nd-order section (Section 2)
    float b0_2 = 1.0;                  // Numerator coefficients for Section 2
    float b1_2 = -1.999928243061207;   // Updated Numerator Coefficient for Section 2
    float b2_2 = 1.0;

    float a1_2 = 1.1241035722388284;  // Updated Denominator coefficients for Section 2
    float a2_2 = 0.5540551124991871;

    // Gain for Section 2
    float gain_2 = 0.5874679077681033;

    // Delay buffers for Section 1
    static float d1_1 = 0, d2_1 = 0;

    // Delay buffers for Section 2
    static float d1_2 = 0, d2_2 = 0;

    // Process the first 2nd-order section (Section 1)
    float xn = sample; // Assume "sample" is the input sample
    float dn_1 = xn - (d1_1 * a1_1) - (d2_1 * a2_1);
    float yn_1 = (dn_1 * b0_1) + (d1_1 * b1_1) + (d2_1 * b2_1);

    // Apply gain for Section 1
    yn_1 *= gain_1;

    // Update delay elements for Section 1
    d2_1 = d1_1;
    d1_1 = dn_1;

    // Process the second 2nd-order section (Section 2)
    float dn_2 = yn_1 - (d1_2 * a1_2) - (d2_2 * a2_2);
    float yn_2 = (dn_2 * b0_2) + (d1_2 * b1_2) + (d2_2 * b2_2);

    // Apply gain for Section 2
    yn_2 *= gain_2;

    // Update delay elements for Section 2
    d2_2 = d1_2;
    d1_2 = dn_2;

    // Return the final output of the cascaded filter
    return yn_2;
}




float calculateEnvelope(float alpha) {

    envelopeSample = alpha * DATAabs[idx] + (1 - alpha) * envelope[idx-1];
    return envelopeSample;
}


void Algorithm_task(void)
{
    while (TRUE)
    {
        Semaphore_pend(semaphore0, BIOS_WAIT_FOREVER);
        DATAclear[idx] = IIR_4thOrder_Cascaded();
        DATAabs[idx] = fabs(DATAclear[idx]);
        if (idx==0)
        {
            envelope[idx]=DATAabs[idx];
        }else{
            envelope[idx] = calculateEnvelope(alpha);

        }
          if (envelope[idx] > threshold) {
              ledFlag=1;
            GPIO_write(USER_LED1, GPIO_PIN_VAL_HIGH); // Turn LED ON
        } else {
            ledFlag=0;
            GPIO_write(USER_LED1, GPIO_PIN_VAL_LOW); // Turn LED OFF
        }
          squareWave[idx] = ledFlag;
  }
}
/*
 *  ======== main ========
 */
int main(void)
{
    /* Call board init functions */
    Board_initGPIO();
    /* Start BIOS */
    BIOS_start();
    return (0);
}
